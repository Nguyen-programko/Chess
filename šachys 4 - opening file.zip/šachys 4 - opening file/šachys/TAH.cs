﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace šachys
{
    class TAH
    {
        public int[] From;
        public int[] To;
        public TAH(int[] from, int[] to)
        {
            From = from; To = to;
        }
    }
}

